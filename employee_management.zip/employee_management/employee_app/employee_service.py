"""Business logic and CRUD operations. (Member 2)"""

from typing import Dict, List

from .models import Employee
from .utils import (
    validate_id,
    validate_name,
    validate_department,
    validate_salary,
    validate_email,
)


class EmployeeService:
    """Manages employees in memory, keyed by employee ID."""

    def __init__(self) -> None:
        self._employees: Dict[int, Employee] = {}

    # ---- Create ----
    def add_employee(self, emp_id, name, department, salary, email) -> Employee:
        emp_id = validate_id(emp_id)
        if emp_id in self._employees:
            raise ValueError(f"Employee ID {emp_id} already exists.")
        email = validate_email(email)
        if any(e.email == email for e in self._employees.values()):
            raise ValueError(f"Email {email} is already in use.")

        employee = Employee(
            emp_id=emp_id,
            name=validate_name(name),
            department=validate_department(department),
            salary=validate_salary(salary),
            email=email,
        )
        self._employees[emp_id] = employee
        return employee

    # ---- Read ----
    def get_employee(self, emp_id) -> Employee:
        emp_id = validate_id(emp_id)
        if emp_id not in self._employees:
            raise KeyError(f"No employee found with ID {emp_id}.")
        return self._employees[emp_id]

    def search_employees(self, query: str) -> List[Employee]:
        """Case-insensitive match on ID, name or department."""
        query = str(query).strip().lower()
        if not query:
            return []
        return [
            e for e in self.get_all_employees()
            if query == str(e.emp_id)
            or query in e.name.lower()
            or query in e.department.lower()
        ]

    def get_all_employees(self) -> List[Employee]:
        return sorted(self._employees.values(), key=lambda e: e.emp_id)

    # ---- Update ----
    def update_employee(self, emp_id, name=None, department=None,
                        salary=None, email=None) -> Employee:
        """Update only the fields that are provided (not None)."""
        employee = self.get_employee(emp_id)

        if email is not None:
            email = validate_email(email)
            if any(e.email == email and e.emp_id != employee.emp_id
                   for e in self._employees.values()):
                raise ValueError(f"Email {email} is already in use.")
            employee.email = email
        if name is not None:
            employee.name = validate_name(name)
        if department is not None:
            employee.department = validate_department(department)
        if salary is not None:
            employee.salary = validate_salary(salary)
        return employee

    # ---- Delete ----
    def delete_employee(self, emp_id) -> Employee:
        employee = self.get_employee(emp_id)
        del self._employees[employee.emp_id]
        return employee

    def count(self) -> int:
        return len(self._employees)
